2020 Ohio precinct and election results shapefile.

## RDH Date retrieval
04/07/2021

## Sources

Election results from the Ohio Secretary of State (https://www.sos.state.oh.us/elections/election-results-and-data/).
Precinct shapefile from the U.S. Census Bureau's 2020 Redistricting Data Program final release. 
Note that some VTDs were relabeled to match precinct names and/or precinct codes in the November 2020 general election returns.

## Fields metadata

Vote Column Label Format
------------------------
Columns reporting votes follow a standard label pattern. One example is:
G20PRERTRU
The first character is G for a general election, P for a primary, C for a caucus, R for a runoff, S for a special.
Characters 2 and 3 are the year of the election.
Characters 4-6 represent the office type (see list below).
Character 7 represents the party of the candidate.
Characters 8-10 are the first three letters of the candidate's last name.

Office Codes

GOV - Governor
PRE - President
PSC - Public Service Commissioner
USS - U.S. Senate

Party Codes
D and R will always represent Democrat and Republican, respectively.
See the state-specific notes for the remaining codes used in a particular file; note that third-party candidates may appear on the ballot under different party labels in different states.


## Fields

GG20PRERTRU - Donald J. Trump (Republican Party)
G20PREDBID - Joseph R. Biden (Democratic Party)
G20PRELJOR - Jo Jorgensen (Libertarian Party)
G20PREGHAW - Howie Hawkins (Independent)

## Processing Steps

The following counties include adjustments to account for corporate annexations that are not specified below by precinct: Adams, Athens, Butler, Franklin, Guernsey, Montgomery, Stark, Tuscarawas, Warren, Wayne.

The following additional revisions were made to match the 2020 precinct boundaries:

Athens: Adjust Athens 4-4/4-5, Nelsonville 1/2/3/4
Brown: Adjust Perry Twp South/Villages
Butler: Adjust Hamilton 22/24, Oxford 6/11, Trenton 5/7, West Chester 28/39
Champaign: Adjust Union N/S
Clark: Align New Carlisle, Springfield precincts with county maps
Crawford: Move eastern Polk Twp from Galion 1B to western Polk Twp
Cuyahoga: Adjust Olmsted Twp D/F/H
Delaware: Adjust Berlin C/Delaware 3-F
Fairfield: Adjust Greenfield B/Lancaster 2-A, Pickerington F/Violet B/Violet C
Greene: Adjust Bath 277/Fairborn 226/Xenia 351
Hamilton: Adjust Cleves A/Whitewater A, Colerain BB/F
Knox: Adjust Clinton A/Mount Vernon 1-B, Clinton B/Mount Vernon 2-A
Lake: Adjust Painesville A/K
Medina: Adjust Wadsworth City 1-D/Sharon D, Wadsworth City 2-D/Twp C
Richland: Adjust Ontario 3/4
Stark: Adjust Canton 8-C/Plain 6, Canton 6-A/Plain 12
Summit: Adjust Coventry D/G, Hudson 1-B/3-C, Springfield F/J
Warren: Adjust Mason City Z/Union A, South Lebanon A/B
